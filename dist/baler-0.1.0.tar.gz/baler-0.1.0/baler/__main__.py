import baler
baler.main()
